//Sheetal Shalini

/* To compile the code, we need to place the folder in the CoinIpopt/Ipopt/examples folder. Once this is done, we need to configure the files by running './configure' in the CoinIpopt folder on the terminal. Then we need to make the files using the command 'make' inside the sent directory. To execute, we need to type the  command './my_example' in the particular directory. Hence the code executes, giving the optimal solution of the function in 11 iterations. */




#include "IpIpoptApplication.hpp"
#include "hs071_nlp.hpp"
#include <iostream>

using namespace Ipopt;

int main(int argv, char* argc[])
{
  // To Create a new instance of nlp
  SmartPtr<TNLP> mynlp = new HS071_NLP();

  // To Create a new instance of IpoptApplication,
  // We are using the factory, since this allows us to compile this example with an Ipopt Windows DLL
  SmartPtr<IpoptApplication> app = IpoptApplicationFactory();
  app->RethrowNonIpoptException(true);
  app->Options()->SetNumericValue("tol", 1e-7);
  app->Options()->SetStringValue("mu_strategy", "adaptive");
  app->Options()->SetStringValue("output_file", "ipopt.out");
  // The following overwrites the default name (ipopt.opt) of the options file
   app->Options()->SetStringValue("option_file_name", "hs071.opt");

  // To Initialize the IpoptApplication and process the options
  ApplicationReturnStatus status;
  status = app->Initialize();
  if (status != Solve_Succeeded) {
    std::cout << std::endl << std::endl << "*** Error during initialization!" << std::endl;
    return (int) status;
  }

  // To Ask Ipopt to solve the problem
  status = app->OptimizeTNLP(mynlp);

  if (status == Solve_Succeeded) {
    std::cout << std::endl << std::endl << "*** The problem solved!" << std::endl;
  }
  else {
    std::cout << std::endl << std::endl << "*** The problem FAILED!" << std::endl;
  }
  return (int) status;
}
